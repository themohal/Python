# Release process

The semantic-release automates the whole package release workflow including: determining the next version number, generating the release notes and publishing to pypi.